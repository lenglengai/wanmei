#include <Startup.h>

#include <iostream>

int main( int argc, char * argv[] )
{
	std::cout << "hello world!" << std::endl;
	std::cin.get();
	return 0;
}
