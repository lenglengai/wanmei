#include "../../include/Include.h"

namespace std {

	Context::Context()
	{
	}
	
	Context::~Context()
	{
	}
	
}
