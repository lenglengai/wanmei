#pragma once

#define APPNAME "cococlient"

#define __CLIENT__
#define __COCOSLOG__
#define __TCPCLIENT__
#define __PING__
