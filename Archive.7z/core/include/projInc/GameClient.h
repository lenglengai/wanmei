#pragma once

#define APPNAME "gameClient"

#define __CLIENT__
#define __BOOSTLOG__
#define __TCPCLIENT__
#define __RUNING__
#define __PING__
#define __CONSOLE__
#define __WITHDEBUG__
