#pragma once

#define APPNAME "loginServer"

#define __SERVER__
#define __WITHCPU__
#define __BOOSTLOG__
#define __TCPSERVER__
#define __RUNING__
#define __PING__
#define __WITHMYSQL__
#define __WITHDEBUG__
