#pragma once

typedef char __i8;
typedef short __i16;
typedef long __i32;
typedef long long __i64;
