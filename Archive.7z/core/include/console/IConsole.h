#pragma once

#ifdef __CONSOLE__
namespace std {

	class IConsole
	{
	public:
	#ifdef __CLIENT__
		virtual void runCommand(list<string>& nCommand) = 0;
	#endif
	#ifdef __SERVER__
		virtual void runCommand(list<string>& nCommand, string& nResult) = 0;
	#endif
	};
	
}
#endif
