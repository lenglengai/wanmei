#pragma once

#ifdef __ACCOUNT__
namespace std {

	class Account
	{
	private:
	};
	
}
#endif
