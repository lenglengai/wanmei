#include "LogService.h"
#include "HandleService.h"
#include "Singleton.h"
#include <iostream>

class LogContext : public std::Context
{
public:
	void runContext()
	{
		std::LogService& logService_ = std::Singleton<std::LogService>::instance();
		logService_.logInfo(log_1("LogContext"));
	}
};

int main(int argc, char * argv[])
{
	std::LogService& logService_ = std::Singleton<std::LogService>::instance();
	logService_.runPreinit();
	std::HandleService& handleService_ = std::Singleton<std::HandleService>::instance();
	handleService_.runInit();
	for (int i = 0; i < 8; ++i) {
		handleService_.addContext(std::ContextPtr(new LogContext), i);
	}
	handleService_.runStart();
	std::cin.get();
	return 0;
}
