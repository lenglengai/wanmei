#pragma once

#include <chrono>

using namespace std::chrono;

#define __WITHTIME__
#define __i64 long long


#define VERHIGH 0
#define VERLOW 1
#define VERBUILD 1

#define BUILDYEAR 2015
#define BUILDMONTH 1
#define BUILDDAY 1

#define STARTYEAR 2014
#define STARTMONTH 10
#define STARTDAY 1

#define ENDYEAR 2015
#define ENDMONTH 10
#define ENDDAY 1

#define INITYEAR 2014
#define INITMONTH 10
#define INITDAY 1

// base alpha beta rc release
#define VERNAME "base"


#ifdef __WITHTIME__
namespace std {

	class TimeService
	{
	public:
		void setServerTime(__i64 nTime);
		__i64 getServerTime();
		__i64 getNowSecond();
		
		static void runScript();
		bool runPreinit();
		void runInit();

	private:
		time_t fromTime(__i32 nYear, __i32 nMonth, __i32 nDay);
		time_t fromTime(__i32 nYear, __i32 nMonth, __i32 nDay, __i32 nHour);
		time_t fromTime(__i32 nYear, __i32 nMonth, __i32 nDay, __i32 nHour, __i32 nMin);
		time_t fromTime(__i32 nYear, __i32 nMonth, __i32 nDay, __i32 nHour, __i32 nMin, __i32 nSec);
		
	public:
		TimeService();
		~TimeService();
		
	private:
		system_clock::time_point mBegin;
		__i64 mCurrent;
	};

}
#endif
