#pragma once

namespace std {

	template<class T>
	class Singleton
	{
	public:
		static T& instance()
		{
			static T t;
			return t;
		}
	};

	template<class T>
	class SingletonPtr
	{
	public:
		static std::shared_ptr<T>& instance()
		{
			static std::shared_ptr<T> t(new T());
			return t;
		}
	};

}
