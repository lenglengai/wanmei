#include "Context.h"

#ifdef __HANDLE__
namespace std {

	Context::Context()
	{
	}
	
	Context::~Context()
	{
	}
	
}
#endif
