#pragma once

#include <thread>
#include <atomic>
#include <list>

#include "Context.h"

#ifdef __HANDLE__
namespace std {

	class Handle
	{
	public:
		void addContext(ContextPtr& nContext);
		void runStart();
		void runStop();

	private:
		bool runInternal();
		void runHandle();
		void runClear();

	public:
		Handle();
		~Handle();

	private:
		std::shared_ptr<std::thread> mThread;
		std::list<ContextPtr> mContexts;
		std::atomic<bool> mStop;
	};
	typedef std::shared_ptr<Handle> HandlePtr;

}
#endif
