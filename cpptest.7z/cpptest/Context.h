#pragma once

#include <memory>

#define __HANDLE__

#define __i32 long

#ifdef __HANDLE__
namespace std {

	class Context
	{
	public:
		virtual void runContext() = 0;
		
		Context();
		virtual ~Context();
	};
	typedef std::weak_ptr<Context> ContextWtr;
	typedef std::shared_ptr<Context> ContextPtr;

}
#endif
