#pragma once

#include "Handle.h"
#include <map>

#ifdef __HANDLE__
namespace std {

	class HandleService
	{
	public:
		void addContext(ContextPtr& nContext, __i32 nIndex);
		__i32 getHandleCount();
		bool runPreinit();
		void runInit();
		void runStart();
		void runStop();

		HandleService();
		~HandleService();

	private:
		std::map<__i32, HandlePtr> mHandles;
		__i32 mHandleCount;
	};

}
#endif
